<?php

set_time_limit(0);

$url = $_GET['u'] ?? '';

if ($url == '') {
    echo "Missing URL";
    exit;
}

$streamContext = stream_context_create([
    'http' => [
        'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36\r\n"
    ]
]);

$parts = parse_url($url);

$query = array();

if (isset($parts['query'])) {
    parse_str($parts['query'], $query);
}




if (strpos($url, "youtube/v3/search") !== false)
{
    $search = urlencode($query['q'] ?? '');
    $max = intval($query['maxResults'] ?? 10);

    // Ask Internet Archive for more results than we need,
    // because some will be rejected by the 20 MB filter.
    $rows = $max * 5;

    $archive =
        "https://archive.org/advancedsearch.php?q="
        . $search .
        "+AND+mediatype:movies+AND+format:%22512Kb+MPEG4%22&fl[]=identifier,title,description&rows="
        . $rows .
        "&output=json";

    $data = file_get_contents($archive, false, $streamContext);

    if ($data === false) {
        echo json_encode([
            "pageInfo" => [
                "totalResults" => 0,
                "resultsPerPage" => $max
            ],
            "items" => []
        ]);
        exit;
    }

    $json = json_decode($data, true);

    $out = [
        "pageInfo" => [
            "totalResults" => 0,
            "resultsPerPage" => $max
        ],
        "items" => []
    ];

    $MAX_SIZE = 20 * 1024 * 1024; // 20 MiB

    foreach ($json["response"]["docs"] ?? [] as $item)
    {
        // Stop once we have enough results for the DS.
        if (count($out["items"]) >= $max)
            break;

        $id = $item["identifier"] ?? "";

        if ($id == "")
            continue;

        // Get the item's file metadata so we can check the
        // actual video file size.
        $metaUrl =
            "https://archive.org/metadata/"
            . urlencode($id);

        $metaData = file_get_contents($metaUrl, false, $streamContext);

        if ($metaData === false)
            continue;

        $meta = json_decode($metaData, true);

        $smallVideoFound = false;

        foreach ($meta["files"] ?? [] as $file)
        {
            $name = strtolower($file["name"] ?? "");

            if (
                str_ends_with($name, ".mp4") ||
                str_ends_with($name, ".3gp")
            )
            {
                $size = intval($file["size"] ?? 0);

                if ($size > 0 && $size < $MAX_SIZE)
                {
                    $smallVideoFound = true;
                    break;
                }
            }
        }

        // No video under 20 MiB -> don't show this result.
        if (!$smallVideoFound)
            continue;

        $out["items"][] = [
            "id" => [
                "videoId" => $id
            ],
            "snippet" => [
                "title" => $item["title"] ?? "Untitled",
                "description" => $item["description"] ?? "",
                "thumbnails" => [
                    "default" => [
                        "url" =>
                        "https://archive.org/download/"
                        . $id .
                        "/__ia_thumb.jpg"
                    ]
                ],
                "channelId" => "internetarchive",
                "channelTitle" => "Internet Archive"
            ]
        ];
    }

    $out["pageInfo"]["totalResults"] = count($out["items"]);

    echo json_encode($out);
}




/*
    Fake old YouTube get_video_info
*/
else if (strpos($url, "get_video_info") !== false)
{

    parse_str(parse_url($url, PHP_URL_QUERY), $query);


    $id = $query["video_id"] ?? "";


    if ($id == "") {
        echo "url_encoded_fmt_stream_map=";
        exit;
    }


    $meta = file_get_contents(
        "https://archive.org/metadata/" . urlencode($id),
        false,
        $streamContext
    );


    if ($meta === false) {
        echo "url_encoded_fmt_stream_map=";
        exit;
    }


    $json = json_decode($meta, true);


    $video = null;


    foreach ($json["files"] ?? [] as $file)
    {
        $name = strtolower($file["name"] ?? "");

        if (
            str_ends_with($name, ".mp4") ||
            str_ends_with($name, ".3gp")
        )
        {
            $video = $file["name"];
            break;
        }
    }


    if ($video)
    {

        $stream =
            "url=" .
            urlencode(
                "https://archive.org/download/"
                . $id .
                "/"
                . $video
            )
            .
            "&itag=17&type=video/mp4";


        echo "url_encoded_fmt_stream_map="
            . urlencode($stream);

    }
    else
    {
        echo "url_encoded_fmt_stream_map=";
    }

}


/*
    Normal HTTPS proxy - with server-side transcode for real video files.
    Anything that looks like a video (.mp4 / .3gp) gets downloaded in full,
    transcoded to exactly 176x144 standard MPEG-4 (the ONE resolution this
    DS decoder was ever built/tuned for), then streamed to the DS.
    Everything else (thumbnails, JSON, etc.) passes through untouched.
*/
else
{
    $lowerUrl = strtolower($url);
    $looksLikeVideo = (strpos($lowerUrl, ".mp4") !== false) || (strpos($lowerUrl, ".3gp") !== false);

    if (!$looksLikeVideo)
    {
        // not a video - plain passthrough (thumbnails, etc.)
        $stream = fopen($url, 'rb', false, $streamContext);
        if ($stream === false) {
            exit;
        }
        while (!feof($stream)) {
            echo fread($stream, 8192);
            flush();
        }
        fclose($stream);
        exit;
    }

    // ---- video file: download, transcode, then stream the result ----

    // EDIT THIS PATH if your ffmpeg lives somewhere else:
    $ffmpegPath = 'C:/Users/PLE0017/AppData/Local/Microsoft/WinGet/Packages/Gyan.FFmpeg.Essentials_Microsoft.Winget.Source_8wekyb3d8bbwe/ffmpeg-8.1.1-essentials_build/bin/ffmpeg.exe';

    $tmpDir = sys_get_temp_dir();
    $uid = uniqid('ytds_', true);
    $srcPath = $tmpDir . DIRECTORY_SEPARATOR . $uid . '_src.mp4';
    $dstPath = $tmpDir . DIRECTORY_SEPARATOR . $uid . '_out.mp4';

    // 1. download the real source video fully to a temp file
    $in = fopen($url, 'rb', false, $streamContext);
    if ($in === false) {
        fwrite(STDERR, "failed to open source url\n");
        exit;
    }
    $out = fopen($srcPath, 'wb');
    while (!feof($in)) {
        fwrite($out, fread($in, 65536));
    }
    fclose($in);
    fclose($out);

    // 2. transcode to 176x144, standard yuv420p MPEG-4, simple settings,
    //    no B-frames / no advanced features this decoder can't handle
    $cmd = escapeshellarg($ffmpegPath)
        . ' -y -i ' . escapeshellarg($srcPath)
        . ' -vf "fps=30000/1001,scale=176:144"'
        . ' -pix_fmt yuv420p'
        . ' -vcodec mpeg4'
        . ' -profile:v 0'
        . ' -level 8'
        . ' -bf 0'
        . ' -slices 1'
        . ' -g 50'
        . ' -b:v 100k'
        . ' -acodec aac'
        . ' -ar 22050'
        . ' -b:a 64k'
        . ' -ac 1'
        . ' -movflags +faststart'
        . ' ' . escapeshellarg($dstPath)
        . ' 2>&1';

    exec($cmd, $ffmpegOutput, $ffmpegReturnCode);

    @unlink($srcPath);

    if ($ffmpegReturnCode !== 0 || !file_exists($dstPath)) {
        fwrite(STDERR, "ffmpeg transcode failed:\n" . implode("\n", $ffmpegOutput) . "\n");
        exit;
    }

    // 3. stream the transcoded file to the DS, same chunked approach as before
    $stream = fopen($dstPath, 'rb');
    if ($stream === false) {
        @unlink($dstPath);
        exit;
    }
    while (!feof($stream)) {
        echo fread($stream, 8192);
        flush();
    }
    fclose($stream);

    @unlink($dstPath);
}

?>