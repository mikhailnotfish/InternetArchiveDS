set(CMAKE_SYSTEM_NAME Generic)

set(CMAKE_C_COMPILER /opt/devkitpro/devkitARM/bin/arm-none-eabi-gcc.exe)
set(CMAKE_AR /opt/devkitpro/devkitARM/bin/arm-none-eabi-ar.exe)

set(CMAKE_TRY_COMPILE_TARGET_TYPE STATIC_LIBRARY)

set(CMAKE_C_FLAGS "-march=armv5te -mtune=arm946e-s -mthumb -mthumb-interwork")
