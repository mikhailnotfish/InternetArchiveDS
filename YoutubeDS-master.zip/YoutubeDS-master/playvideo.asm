
YoutubeDS-master.elf:     file format elf32-littlearm


Disassembly of section .itcm:

01000cc8 <_Z9PlayVideov>:
 1000cc8:	e92d41f0 	push	{r4, r5, r6, r7, r8, lr}
 1000ccc:	e3e0c000 	mvn	ip, #0
 1000cd0:	e3a05000 	mov	r5, #0
 1000cd4:	e59f409c 	ldr	r4, [pc, #156]	; 1000d78 <_Z9PlayVideov+0xb0>
 1000cd8:	e59f309c 	ldr	r3, [pc, #156]	; 1000d7c <_Z9PlayVideov+0xb4>
 1000cdc:	e2846ee9 	add	r6, r4, #3728	; 0xe90
 1000ce0:	e59f2098 	ldr	r2, [pc, #152]	; 1000d80 <_Z9PlayVideov+0xb8>
 1000ce4:	e2866008 	add	r6, r6, #8
 1000ce8:	e5835018 	str	r5, [r3, #24]
 1000cec:	e1a01005 	mov	r1, r5
 1000cf0:	e582c000 	str	ip, [r2]
 1000cf4:	e1a00006 	mov	r0, r6
 1000cf8:	e3a0202e 	mov	r2, #46	; 0x2e
 1000cfc:	e5835024 	str	r5, [r3, #36]	; 0x24
 1000d00:	e5845e80 	str	r5, [r4, #3712]	; 0xe80
 1000d04:	e5835028 	str	r5, [r3, #40]	; 0x28
 1000d08:	e5c45e84 	strb	r5, [r4, #3716]	; 0xe84
 1000d0c:	e5845e7c 	str	r5, [r4, #3708]	; 0xe7c
 1000d10:	e5835000 	str	r5, [r3]
 1000d14:	eb40bd2e 	bl	20301d4 <memset>
 1000d18:	e3a000b0 	mov	r0, #176	; 0xb0
 1000d1c:	e3a01090 	mov	r1, #144	; 0x90
 1000d20:	e59f305c 	ldr	r3, [pc, #92]	; 1000d84 <_Z9PlayVideov+0xbc>
 1000d24:	e2842eed 	add	r2, r4, #3792	; 0xed0
 1000d28:	e5d5c008 	ldrb	ip, [r5, #8]
 1000d2c:	e59f7054 	ldr	r7, [pc, #84]	; 1000d88 <_Z9PlayVideov+0xc0>
 1000d30:	e2822008 	add	r2, r2, #8
 1000d34:	e59fe050 	ldr	lr, [pc, #80]	; 1000d8c <_Z9PlayVideov+0xc4>
 1000d38:	e59fc050 	ldr	ip, [pc, #80]	; 1000d90 <_Z9PlayVideov+0xc8>
 1000d3c:	e1c600b4 	strh	r0, [r6, #4]
 1000d40:	e59f004c 	ldr	r0, [pc, #76]	; 1000d94 <_Z9PlayVideov+0xcc>
 1000d44:	e5842e98 	str	r2, [r4, #3736]	; 0xe98
 1000d48:	e1c610b6 	strh	r1, [r6, #6]
 1000d4c:	e2832ebd 	add	r2, r3, #3024	; 0xbd0
 1000d50:	e2831e75 	add	r1, r3, #1872	; 0x750
 1000d54:	e2833ee1 	add	r3, r3, #3600	; 0xe10
 1000d58:	e5847ea0 	str	r7, [r4, #3744]	; 0xea0
 1000d5c:	e584eea4 	str	lr, [r4, #3748]	; 0xea4
 1000d60:	e584ceb0 	str	ip, [r4, #3760]	; 0xeb0
 1000d64:	e5840eb4 	str	r0, [r4, #3764]	; 0xeb4
 1000d68:	e5841eb8 	str	r1, [r4, #3768]	; 0xeb8
 1000d6c:	e5842ebc 	str	r2, [r4, #3772]	; 0xebc
 1000d70:	e5843ec0 	str	r3, [r4, #3776]	; 0xec0
 1000d74:	e7f000f0 	udf	#0
 1000d78:	020d0ae8 	.word	0x020d0ae8
 1000d7c:	02052ce0 	.word	0x02052ce0
 1000d80:	020501a8 	.word	0x020501a8
 1000d84:	020eea70 	.word	0x020eea70
 1000d88:	020e19c0 	.word	0x020e19c0
 1000d8c:	020ea9c0 	.word	0x020ea9c0
 1000d90:	02008520 	.word	0x02008520
 1000d94:	0200a5e0 	.word	0x0200a5e0

01000d98 <irqTable>:
	...

01000e60 <IntrMain>:
 1000e60:	e3a0c301 	mov	ip, #67108864	; 0x4000000
 1000e64:	e59c1208 	ldr	r1, [ip, #520]	; 0x208
 1000e68:	e3510000 	cmp	r1, #0
 1000e6c:	012fff1e 	bxeq	lr
 1000e70:	e3a00000 	mov	r0, #0
 1000e74:	e58c0208 	str	r0, [ip, #520]	; 0x208
 1000e78:	e14f0000 	mrs	r0, SPSR
 1000e7c:	e92d5003 	push	{r0, r1, ip, lr}
 1000e80:	e28cce21 	add	ip, ip, #528	; 0x210
 1000e84:	e89c0006 	ldm	ip, {r1, r2}
 1000e88:	e0111002 	ands	r1, r1, r2
 1000e8c:	e59f0090 	ldr	r0, [pc, #144]	; 1000f24 <IntrRet+0x20>
 1000e90:	e59f2090 	ldr	r2, [pc, #144]	; 1000f28 <IntrRet+0x24>

01000e94 <setflags>:
 1000e94:	e5903000 	ldr	r3, [r0]
 1000e98:	e1833001 	orr	r3, r3, r1
 1000e9c:	e5803000 	str	r3, [r0]

01000ea0 <findIRQ>:
 1000ea0:	e5920004 	ldr	r0, [r2, #4]
 1000ea4:	e3500000 	cmp	r0, #0
 1000ea8:	0a000003 	beq	1000ebc <no_handler>
 1000eac:	e0100001 	ands	r0, r0, r1
 1000eb0:	1a000005 	bne	1000ecc <jump_intr>
 1000eb4:	e2822008 	add	r2, r2, #8
 1000eb8:	eafffff8 	b	1000ea0 <findIRQ>

01000ebc <no_handler>:
 1000ebc:	e58c1004 	str	r1, [ip, #4]
 1000ec0:	e8bd5003 	pop	{r0, r1, ip, lr}
 1000ec4:	e58c1208 	str	r1, [ip, #520]	; 0x208
 1000ec8:	e1a0f00e 	mov	pc, lr

01000ecc <jump_intr>:
 1000ecc:	e5921000 	ldr	r1, [r2]
 1000ed0:	e3510000 	cmp	r1, #0
 1000ed4:	1a000001 	bne	1000ee0 <got_handler>
 1000ed8:	e1a01000 	mov	r1, r0
 1000edc:	eafffff6 	b	1000ebc <no_handler>

01000ee0 <got_handler>:
 1000ee0:	e58c0004 	str	r0, [ip, #4]
 1000ee4:	e10f2000 	mrs	r2, CPSR
 1000ee8:	e1a03002 	mov	r3, r2
 1000eec:	e3c330df 	bic	r3, r3, #223	; 0xdf
 1000ef0:	e383301f 	orr	r3, r3, #31
 1000ef4:	e129f003 	msr	CPSR_fc, r3
 1000ef8:	e92d4004 	push	{r2, lr}
 1000efc:	e28fe000 	add	lr, pc, #0
 1000f00:	e12fff11 	bx	r1

01000f04 <IntrRet>:
 1000f04:	e3a0c301 	mov	ip, #67108864	; 0x4000000
 1000f08:	e58cc208 	str	ip, [ip, #520]	; 0x208
 1000f0c:	e8bd4004 	pop	{r2, lr}
 1000f10:	e129f002 	msr	CPSR_fc, r2
 1000f14:	e8bd5003 	pop	{r0, r1, ip, lr}
 1000f18:	e169f000 	msr	SPSR_fc, r0
 1000f1c:	e58c1208 	str	r1, [ip, #520]	; 0x208
 1000f20:	e1a0f00e 	mov	pc, lr
 1000f24:	0b003ff8 	.word	0x0b003ff8
 1000f28:	01000d98 	.word	0x01000d98
 1000f2c:	ffffffff 	.word	0xffffffff

01000f30 <__keysHeld_from_arm>:
 1000f30:	e59fc000 	ldr	ip, [pc]	; 1000f38 <__keysHeld_from_arm+0x8>
 1000f34:	e12fff1c 	bx	ip
 1000f38:	0201635d 	.word	0x0201635d

01000f3c <__scanKeys_from_arm>:
 1000f3c:	e59fc000 	ldr	ip, [pc]	; 1000f44 <__scanKeys_from_arm+0x8>
 1000f40:	e12fff1c 	bx	ip
 1000f44:	020162f1 	.word	0x020162f1
	...
