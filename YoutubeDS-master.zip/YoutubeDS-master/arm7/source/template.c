/*---------------------------------------------------------------------------------

	Classic (pre-Calico) ARM7 core
	Adapted for YoutubeDS to restore compatibility with classic dswifi7,
	replacing the Calico-based wlmgr default template.
	Maxmod is not used by this project, so it has been omitted.

---------------------------------------------------------------------------------*/
#include <nds.h>
#include <dswifi7.h>

//---------------------------------------------------------------------------------
void VblankHandler(void) {
//---------------------------------------------------------------------------------
	Wifi_Update();
}

//---------------------------------------------------------------------------------
void VcountHandler() {
//---------------------------------------------------------------------------------
	inputGetAndSend();
}

volatile bool exitflag = false;

//---------------------------------------------------------------------------------
void powerButtonCB() {
//---------------------------------------------------------------------------------
	exitflag = true;
}

//---------------------------------------------------------------------------------
int main() {
//---------------------------------------------------------------------------------
	irqInit();
	fifoInit();

	readUserSettings();

	// Install the classic dswifi7 FIFO handler so ARM9's Wifi_Init()/
	// Wifi_InitDefault() calls actually reach this ARM7 driver.
	installWifiFIFO();
	installSoundFIFO();
	installSystemFIFO();

	irqSet(IRQ_VCOUNT, VcountHandler);
	irqSet(IRQ_VBLANK, VblankHandler);

	irqEnable(IRQ_VBLANK | IRQ_VCOUNT | IRQ_NETWORK);

	setPowerButtonCB(powerButtonCB);

	// Keep the ARM7 idle, servicing wifi/sound/input via interrupts
	while (!exitflag) {
		swiWaitForVBlank();
	}

	return 0;
}
