#ifndef __YOUTUBE_APIKEY_H__
#define __YOUTUBE_APIKEY_H__

extern const char* youtube_apikey;
extern const char* youtube_server_ip;

#endif