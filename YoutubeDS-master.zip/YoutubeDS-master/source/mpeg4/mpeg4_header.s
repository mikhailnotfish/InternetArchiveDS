@We'll use stride 256 to make it more suiteable for displaying on a ds
.equ STRIDE, 256
.equ STRIDE_SHIFT, 8

@r0 has the following structure:
@uint8_t* pData
@uint16_t width
@uint16_t height
@uint8_t* pDstY
@uint8_t* pDstUV
@uint8_t* pPrevY
@uint8_t* pPrevUV
@uint16_t* pIntraDCTVLCTable
@uint16_t* pInterDCTVLCTable
@int16_t* pdc_coef_cache_y
@int16_t* pdc_coef_cache_uv
@int16_t* pvector_cache
@uint8_t vop_time_increment_bits
@uint8_t vop_fcode_forward

.equ mpeg4_dec_struct__pData, 0
.equ mpeg4_dec_struct__width, 4
.equ mpeg4_dec_struct__height, 6
.equ mpeg4_dec_struct__pDstY, 8
.equ mpeg4_dec_struct__pDstUV, 12
.equ mpeg4_dec_struct__pPrevY, 16
.equ mpeg4_dec_struct__pPrevUV, 20
.equ mpeg4_dec_struct__pIntraDCTVLCTable, 24
.equ mpeg4_dec_struct__pInterDCTVLCTable, 28
.equ mpeg4_dec_struct__pdc_coef_cache_y, 32
.equ mpeg4_dec_struct__pdc_coef_cache_uv, 36
.equ mpeg4_dec_struct__pvector_cache, 40
.equ mpeg4_dec_struct__vop_time_increment_bits, 44
.equ mpeg4_dec_struct__vop_fcode_forward, 45
