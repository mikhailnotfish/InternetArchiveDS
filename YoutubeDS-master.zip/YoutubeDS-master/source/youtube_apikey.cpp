#include <nds.h>
#include "youtube_apikey.h"

//PUT YOUR IP ADRESS IN THE "" 
const char* youtube_server_ip = "";